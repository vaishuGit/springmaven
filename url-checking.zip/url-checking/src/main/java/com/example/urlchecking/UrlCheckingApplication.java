package com.example.urlchecking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrlCheckingApplication {

	public static void main(String[] args) {
		SpringApplication.run(UrlCheckingApplication.class, args);
	}

}
